import 'package:flutter/material.dart';

abstract class AppColors {
  static const primary = Color(0xfff15941);
  static const primaryDark = Color(0xff953828);
  static const primary80 = Color(0xfff5826d);
  static const primaryLight = Color(0xfff5c1b8);

  static const secondary = Color(0xffF98600);
  static const secondaryLight = Color(0xffFFF9E5);

  static const tealGreen = Color(0xff45d364);
  static const accent = Color(0xffED4C5C);
  static const accentLight = Color(0xffFEF1F2);
  static const darkBg = Color(0xff0d0d0d);
  static const white = Color(0xffFFFFFF);
  static const black = Color(0xff000000);
  static const darkText = Color(0xff202124);
  static const lightBack = Color(0xfff9f3f1);
  static const greyText = Color(0xff797c7b);

  static const grey100 = Color(0xff161616);
  static const grey90 = Color(0xff262626);
  static const grey80 = Color(0xff50555C);
  static const grey70 = Color(0xff767f86);
  static const grey60 = Color(0xffADB3BC);
  static const grey40 = Color(0xffD1D5DB);
  static const grey30 = Color(0xffe3e6e8);
  static const grey20 = Color(0xffF0F3F6);

  static const light80 = Color(0xffFDFDFD);
  static const light60 = Color(0xff8D8D8D);
}
